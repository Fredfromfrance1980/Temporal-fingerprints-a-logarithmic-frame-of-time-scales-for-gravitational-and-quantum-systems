# -*- coding: utf-8 -*-
"""Figures of the paper. Usage: python figures.py fr|en  -> figures/<lang>/*.pdf"""
import sys, os, csv, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from empreintes import *
L = sys.argv[1] if len(sys.argv) > 1 else "fr"
T = {
 "fr": dict(sec="secondes", xX=r"$\log_{10}X=\log_{10}(T_G/T_C)$", yY=r"$\log_{10}Y=\log_{10}(T_P/T_G)$",
            yO=r"$\log_{10}O=\log_{10}(T_{\rm obs}/T_C)$", hor="$r_s$ : $X=1/2$", isco="ISCO $X=1/6$",
            pm="masse de Planck $Y=1$", comp=r"Compton $XY^2=1$", pl="longueur de Planck $XY=1$",
            forb="$R<r_s$ (Schwarzschild)", qu="R sous la longueur\nde Compton", kep=r"Kepler $O\sqrt{X}=2\pi$",
            kepgw=r"Kepler, onde grav. $O\sqrt{X}=\pi$", orb="orbites", oth="autres horloges",
            phiG=r"$\log_{10}\varphi_G$ (auto-gravité)", phiC=r"$\log_{10}\varphi_{\rm horloge}$ (temps propre)",
            q=["Q1 : quantique ordinaire", "Q2 : temps propre lisible", "Q3 : auto-gravité active", "Q4 : les deux"],
            seg="variation de $\\Delta x$", cats={"quantique":"quantique","Terre":"Terre","Système solaire":"Système solaire","Étoiles":"étoiles et objets compacts","Noyaux galactiques":"noyaux galactiques","Galaxie":"galaxie","Cosmos":"cosmos"}),
 "en": dict(sec="seconds", xX=r"$\log_{10}X=\log_{10}(T_G/T_C)$", yY=r"$\log_{10}Y=\log_{10}(T_P/T_G)$",
            yO=r"$\log_{10}O=\log_{10}(T_{\rm obs}/T_C)$", hor="$r_s$ : $X=1/2$", isco="ISCO $X=1/6$",
            pm="Planck mass $Y=1$", comp=r"Compton $XY^2=1$", pl="Planck length $XY=1$",
            forb="$R<r_s$ (Schwarzschild)", qu="R below the\nCompton length", kep=r"Kepler $O\sqrt{X}=2\pi$",
            kepgw=r"Kepler, GW period $O\sqrt{X}=\pi$", orb="orbits", oth="other clocks",
            phiG=r"$\log_{10}\varphi_G$ (self-gravity)", phiC=r"$\log_{10}\varphi_{\rm clock}$ (proper time)",
            q=["Q1: ordinary quantum", "Q2: proper time readable", "Q3: self-gravity active", "Q4: both"],
            seg="varying $\\Delta x$", cats={"quantique":"quantum","Terre":"Earth","Système solaire":"Solar System","Étoiles":"stars and compact objects","Noyaux galactiques":"galactic nuclei","Galaxie":"galaxy","Cosmos":"cosmos"}),
}[L]
os.makedirs(f"figures/{L}", exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 9, "mathtext.fontset": "cm",
                     "axes.spines.top": False, "axes.spines.right": False})
rows = list(csv.DictReader(open("atlas_temporel.csv", encoding="utf-8")))
COL = {"quantique": "#2f7d4f", "Terre": "#1f5fbf", "Système solaire": "#4b8fd6", "Étoiles": "#c2410c",
       "Noyaux galactiques": "#7c3aed", "Galaxie": "#9a6b00", "Cosmos": "#1f2328"}

# ---------------- Fig 1: plane (log X, log Y) = hyperplane arrangement
fig, ax = plt.subplots(figsize=(6.6, 4.8))
xs = np.linspace(-56, 3, 10)
ax.fill_betweenx([-65, 25], np.log10(0.5), 3, color="#f1e3dc", lw=0)
yy = np.linspace(-65, 25, 200)
ax.fill_between(np.linspace(-56, 3, 200), -0.5*np.linspace(-56, 3, 200), 25, color="#e2eef5", lw=0)
ax.axvline(np.log10(0.5), color="#c2410c", lw=1.1); ax.axvline(np.log10(1/6), color="#c2410c", lw=.8, ls="--")
ax.axhline(0, color="#555", lw=.8, ls=":")
ax.plot(xs, -0.5*xs, color="#1f5fbf", lw=1.1)
ax.plot(xs, -xs, color="#555", lw=.8, ls="-.")
for r in rows:
    ax.scatter(float(r["log10_X"]), float(r["log10_Y"]), s=18, color=COL[r["categorie"]], zorder=3, edgecolor="white", lw=.4)
for k, v in COL.items():
    ax.scatter([], [], s=18, color=v, label=T["cats"][k])
ax.text(1.0, 2, T["forb"], fontsize=7, color="#8a3b12", rotation=90)
ax.text(-54, 23.5, T["qu"], fontsize=7.5, color="#1f5fbf", va="top")
ax.text(np.log10(0.5)+.3, -62, T["hor"], rotation=90, fontsize=7, color="#c2410c")
ax.text(np.log10(1/6)-1.6, -62, T["isco"], rotation=90, fontsize=7, color="#c2410c")
ax.text(-40, 0.8, T["pm"], fontsize=7, color="#555")
ax.text(-24, 14.0, T["comp"], fontsize=7, color="#1f5fbf", rotation=-20)
ax.text(-11.5, 13.5, T["pl"], fontsize=6.5, color="#555", rotation=-36)
ax.text(-30, 31-3, "", fontsize=7)
ax.set_xlim(-56, 3); ax.set_ylim(-65, 25); ax.set_xlabel(T["xX"]); ax.set_ylabel(T["yY"])
ax.legend(frameon=False, fontsize=7, loc="lower left")
fig.tight_layout(); fig.savefig(f"figures/{L}/fig_plan_XY.pdf")

# ---------------- Fig 2: plane (log X, log O) = clocks
fig, ax = plt.subplots(figsize=(6.6, 4.3))
xs = np.linspace(-56, 0, 10)
ax.plot(xs, np.log10(2*np.pi) - 0.5*xs, color="#1f2328", lw=1.1, label=T["kep"])
ax.plot(xs, np.log10(np.pi) - 0.5*xs, color="#1f2328", lw=.8, ls="--", label=T["kepgw"])
for r in rows:
    if not r["log10_O"]: continue
    orb = r["residu_Kepler"] != ""
    ax.scatter(float(r["log10_X"]), float(r["log10_O"]), s=24 if orb else 18, marker="o" if orb else "s",
               color=COL[r["categorie"]], edgecolor="white", lw=.4, zorder=3)
ax.scatter([], [], marker="o", color="#888", label=T["orb"]); ax.scatter([], [], marker="s", color="#888", label=T["oth"])
ax.axvline(np.log10(1/6), color="#c2410c", lw=.8, ls="--")
ax.set_xlabel(T["xX"]); ax.set_ylabel(T["yO"]); ax.set_xlim(-56, 1); ax.set_ylim(-1, 30)
ax.legend(frameon=False, fontsize=7.5, loc="upper right")
fig.tight_layout(); fig.savefig(f"figures/{L}/fig_plan_XO.pdf")

# ---------------- Fig 3: quantum quadrants (phi_G, phi_clock), optical clock assumed, Earth field
g = 9.81; dE = 2*eV
EXP = [("COW", 1.6749e-27, 0.035, 1.09e-5), ("Rb 54 cm", 1.443e-25, 0.54, 2.08), ("Cs 20 s", 2.207e-25, 3.9e-6, 20.0),
       ("25 kDa", 4.15e-23, 2.66e-7, 7.7e-3), ("BMV", 1e-14, 2.5e-4, 2.5),
       ("1e-14 kg, 218 s", 1e-14, 1.38e-2, 218.0)]
fig, ax = plt.subplots(figsize=(6.0, 4.6))
ax.axvline(0, color="#1f2328", lw=.9); ax.axhline(0, color="#1f2328", lw=.9)
ax.fill_between([0, 45], 0, 45, color="#e2eef5", lw=0)
for name, m, dx, Tt in EXP:
    dxs = dx*np.logspace(-2, 2, 50)
    pg = np.log10(phi_G(m, dxs, Tt)); pc = np.log10(phi_clock(dE, dtau_potential(g, dxs, Tt)))
    ax.plot(pg, pc, color="#9aa6b2", lw=.8)
    x0 = np.log10(phi_G(m, dx, Tt)); y0 = np.log10(phi_clock(dE, dtau_potential(g, dx, Tt)))
    ax.scatter(x0, y0, s=26, color="#2f7d4f" if "218" not in name else "white", edgecolor="#2f7d4f", zorder=3)
    ax.annotate(name, (x0, y0), xytext=(4, 4), textcoords="offset points", fontsize=7)
ax.set_xlim(-42, 6); ax.set_ylim(-14, 6)
for (x, y, t) in [(-41, -13.3, T["q"][0]), (-41, 4.9, T["q"][1]), (0.4, -13.3, T["q"][2]), (0.4, 4.9, T["q"][3])]:
    ax.text(x, y, t, fontsize=7.5, color="#555")
ax.set_xlabel(T["phiG"]); ax.set_ylabel(T["phiC"])
ax.text(-25, -6.2, T["seg"], fontsize=7, color="#7a8794", rotation=-22)
fig.tight_layout(); fig.savefig(f"figures/{L}/fig_quadrants.pdf")

# ---------------- Fig 4: ladder of time scales for a few systems
sel = ["Hydrogène, orbite de Bohr", "Neutrons en superposition (COW 1975)", "Terre, surface (rotation sidérale)",
       "Terre autour du Soleil", "Double pulsar J0737−3039, orbite", "GW150914 à 40 Hz", "S2 autour de Sgr A*",
       "Sphère de Hubble aujourd'hui"]
lab_en = {"Hydrogène, orbite de Bohr": "Hydrogen, Bohr orbit", "Neutrons en superposition (COW 1975)": "Neutrons (COW 1975)",
          "Terre, surface (rotation sidérale)": "Earth surface (rotation)", "Terre autour du Soleil": "Earth around the Sun",
          "Double pulsar J0737−3039, orbite": "Double pulsar, orbit", "GW150914 à 40 Hz": "GW150914 at 40 Hz",
          "S2 autour de Sgr A*": "S2 around Sgr A*", "Sphère de Hubble aujourd'hui": "Hubble sphere today"}
fig, ax = plt.subplots(figsize=(6.6, 3.6))
mk = {"T_P_s": ("|", "#555", "$T_P$"), "T_Q_s": ("D", "#2f7d4f", "$T_Q$"), "T_G_s": ("o", "#c2410c", "$T_G$"),
      "T_C_s": ("s", "#1f5fbf", "$T_C$"), "T_obs_s": ("*", "#1f2328", r"$T_{\rm obs}$")}
by = {r["systeme"]: r for r in rows}
for i, s in enumerate(sel):
    r = by[s]; ax.axhline(i, color="#eee", lw=.6, zorder=0)
    for k, (m_, col, lab) in mk.items():
        if r[k]:
            ax.scatter(np.log10(float(r[k])), i, marker=m_, s=40 if m_ == "*" else 22, color=col, zorder=3,
                       label=lab if i == 0 else None)
ax.set_yticks(range(len(sel)), [s if L == "fr" else lab_en[s] for s in sel], fontsize=7.5)
ax.set_xlabel(r"$\log_{10}$ " + T["sec"]); ax.set_xlim(-62, 20)
ax.legend(frameon=False, fontsize=7.5, ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.13))
fig.tight_layout(); fig.savefig(f"figures/{L}/fig_echelle.pdf")
print("figures written to figures/" + L)
