# -*- coding: utf-8 -*-
"""Tests: every identity stated in the paper is checked numerically.  Run: python test_empreintes.py"""
import numpy as np
from empreintes import *

def close(a, b, tol=1e-9): return abs(a - b) <= tol * max(1, abs(b))

def test_planck():
    assert close(T_G(M_P), T_P)                       # T_G(M_P) = T_P
    assert close(L_P, c * T_P)

def test_compton_identity():
    for m in [9.109e-31, 1.6726e-27, 1e-14, M_P, 1.0]:
        assert close(T_G(m) * T_Q(m), T_P**2)          # T_G T_Q = T_P^2
        assert close((T_P / T_G(m))**2, T_Q(m) / T_G(m))

def test_products():
    f = Fingerprint(5.972e24, 6.371e6)
    assert close(f.X * f.Y, L_P / f.R)                 # XY = T_P/T_C = L_P/R
    assert close(f.X**2 * f.Y, (G * f.M / f.R**2) / a_P)   # X^2 Y = g/a_P

def test_scale_invariance():
    assert np.allclose(scale_invariance_check(), 0)

def test_buckingham():
    r, B = buckingham()
    assert r == 3 and B.shape == (3, 6)

def test_kepler():
    M, R = GM_sun / G, AU
    P = 2 * np.pi * np.sqrt(R**3 / (G * M))
    f = Fingerprint(M, R, P, "orbit")
    assert abs(f.kepler_residual()) < 1e-12
    assert close(f.O * np.sqrt(f.X), 2 * np.pi)

def test_schwarzschild():
    f = Fingerprint(M_sun, 2 * G * M_sun / c**2)
    assert close(f.X, 0.5) and f.F_static == 0.0

def test_horizon():
    for H in [2.2e-18, 1e-13, 1e5]:
        assert close(hubble_fingerprint(H).X, 0.5)
        assert close(hubble_fingerprint(H, 1.02).X, 0.51)

def test_quantum_product():
    m, dx, T, dE, g = 1e-14, 2.5e-4, 2.5, 2 * eV, 9.81
    p = phi_G(m, dx, T) * phi_clock(dE, dtau_potential(g, dx, T))
    Y = M_P / m
    assert close(p, T**2 / (Y**2 * (hbar / dE) * (c / g)))
    # independence from dx
    p2 = phi_G(m, 10 * dx, T) * phi_clock(dE, dtau_potential(g, 10 * dx, T))
    assert close(p, p2)
    T4 = q4_threshold(m, dE, g)
    assert close(phi_G(m, dx, T4) * phi_clock(dE, dtau_potential(g, dx, T4)), 1.0)

def test_eliminate():
    # columns: ln m, ln dx, ln T, ln dE, ln g ; rows: ln phi_G, ln phi_clock (constants omitted)
    C = np.array([[2, -1, 1, 0, 0], [0, 1, 1, 1, 1]], float)
    w = eliminate(C, [1])[0]
    assert np.allclose(w / w[0], [1, 1])

if __name__ == "__main__":
    n = 0
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v(); n += 1; print("ok", k)
    print(n, "tests passed")
