# -*- coding: utf-8 -*-
"""
Atlas temporel / Temporal atlas -- builds atlas_temporel.csv from documented inputs.

Each row: mass M, length R, optional observed time T_obs, the nature of R (measured / derived / assumed),
the nature of T_obs, and a source. Values are rounded published values; the 'R_statut' column states
whether R is independent of T_obs (only then is a Kepler residual a test rather than an identity).
"""
import numpy as np, csv
from empreintes import *

kep = lambda GM, P: (GM * P**2 / (4 * np.pi**2)) ** (1/3)
m_p, m_e, m_H = 1.672_621_924e-27, 9.109_383_70e-31, 1.007_825_03 * 1.660_539_067e-27
a0 = 5.291_772_109e-11
GM_E = 3.986_004_418e14
M_E = GM_E / G
ROWS = []
def add(cat, name, M, R, T=None, clock=None, R_stat="mesuré", T_stat="", src=""):
    ROWS.append(dict(cat=cat, name=name, M=M, R=R, T=T, clock=clock, R_stat=R_stat, T_stat=T_stat, src=src))

# ---- quantum and atomic
add("quantique", "Électron (échelle de Compton réduite)", m_e, hbar/(m_e*c), None, None, "défini", "",
    "CODATA 2018")
add("quantique", "Proton (rayon de charge)", m_p, 0.8409e-15, None, None, "mesuré", "", "CODATA 2018")
add("quantique", "Hydrogène, orbite de Bohr", m_H, a0, 2*np.pi*hbar/(4.359_744_722e-18), "other",
    "défini", "période de Bohr 2πħ/E_h", "CODATA 2018")
add("quantique", "Hydrogène, raie à 21 cm (maser)", m_H, a0, 1/1.420_405_751_768e9, "other",
    "défini", "période hyperfine", "Hellwig et al. 1970")
add("quantique", "Neutrons en superposition (COW 1975)", 1.674_927_5e-27, 0.035, 1.09e-5, "other",
    "mesuré", "durée effective déduite de la phase publiée", "Colella, Overhauser & Werner 1975")
add("quantique", "Atomes Rb, 54 cm (2015)", 86.909 * 1.660_539e-27, 0.54, 2.08, "other",
    "mesuré", "durée de superposition (ordre de grandeur)", "Kovachy et al. 2015")
add("quantique", "Atomes Cs piégés 20 s (2019)", 132.905 * 1.660_539e-27, 3.9e-6, 20.0, "other",
    "mesuré", "durée de maintien", "Xu et al. 2019")
add("quantique", "Molécules 25 kDa (2019)", 25000 * 1.660_539e-27, 2.66e-7, 7.7e-3, "other",
    "ordre de grandeur", "temps de vol (ordre de grandeur)", "Fein et al. 2019")
add("quantique", "Microdiamant 1e-14 kg (proposition BMV)", 1e-14, 2.5e-4, 2.5, "other",
    "proposé", "durée proposée", "Bose et al. 2017")
add("quantique", "Masse de Planck à la longueur de Planck", M_P, L_P, None, None, "défini", "", "définition")

# ---- Earth environment
add("Terre", "Terre, surface (rotation sidérale)", M_E, 6.371_0e6, 86164.0905, "other",
    "mesuré", "rotation sidérale", "IERS ; IAU")
add("Terre", "Station spatiale internationale", M_E, 6.371e6 + 4.20e5, 92.9*60, "orbit",
    "mesuré", "période orbitale", "NASA (ordre de grandeur, altitude 420 km)")
add("Terre", "Satellite GPS", M_E, 26_560e3, 43_082.0, "orbit",
    "mesuré", "période orbitale", "US GPS Interface Specification")
add("Terre", "Lune autour de la Terre", GM_E/G * (1 + 0.012_300_037), 384_399e3, 27.321_661*day, "orbit",
    "mesuré", "période sidérale", "NASA Moon Fact Sheet")

# ---- Solar system
add("Système solaire", "Soleil, surface (rotation équatoriale)", GM_sun/G, 6.957e8, 25.38*day, "other",
    "mesuré", "rotation sidérale équatoriale", "IAU 2015 ; NASA Sun Fact Sheet")
for nm, a, P in [("Mercure", 0.387_098, 87.9691), ("Terre", 1.000_001_018, 365.256_363),
                 ("Jupiter", 5.2044, 4332.59), ("Neptune", 30.07, 60_190.0)]:
    add("Système solaire", f"{nm} autour du Soleil", GM_sun/G, a*AU, P*day, "orbit",
        "mesuré (mais GM☉ est calibré sur les orbites)", "période sidérale", "NASA Planetary Fact Sheets")

# ---- stars and compact objects
add("Étoiles", "Sirius B, surface (naine blanche)", 1.018*M_sun, 0.0081*6.957e8, None, None,
    "mesuré", "", "Bond et al. 2017")
add("Étoiles", "Sirius A–B, orbite", 3.081*M_sun, kep(3.081*GM_sun, 50.13*yr), 50.13*yr, "orbit",
    "déduit (Kepler)", "période orbitale", "Bond et al. 2017")
add("Étoiles", "PSR J0740+6620, surface (étoile à neutrons)", 2.08*M_sun, 12.39e3, 2.8858e-3, "other",
    "mesuré (NICER)", "période de rotation", "Fonseca et al. 2021 ; Riley et al. 2021")
add("Étoiles", "Pulsar du Crabe, surface", 1.4*M_sun, 12e3, 33.6e-3, "other",
    "supposé (M, R typiques)", "période de rotation", "Lyne et al. 1993 (période)")
add("Étoiles", "PSR B1913+16, orbite", 2.828*M_sun, kep(2.828*GM_sun, 27906.98), 27906.98, "orbit",
    "déduit (Kepler)", "période orbitale", "Weisberg & Huang 2016")
add("Étoiles", "Double pulsar J0737−3039, orbite", 2.587*M_sun, kep(2.587*GM_sun, 8834.535), 8834.535, "orbit",
    "déduit (Kepler)", "période orbitale", "Kramer et al. 2021")
add("Étoiles", "Cygnus X-1, horizon", 21.2*M_sun, 2*G*21.2*M_sun/c**2, None, None,
    "défini (rayon de Schwarzschild)", "", "Miller-Jones et al. 2021")
add("Étoiles", "GW150914 à 40 Hz", 65.3*M_sun, kep(65.3*GM_sun, 0.05), 0.025, "gw",
    "déduit (Kepler)", "période de l'onde", "LVK 2016")

# ---- galactic nuclei
add("Noyaux galactiques", "S2 autour de Sgr A*", 4.30e6*M_sun, kep(4.30e6*GM_sun, 16.046*yr), 16.046*yr, "orbit",
    "déduit (Kepler)", "période orbitale", "GRAVITY Collaboration 2020")
add("Noyaux galactiques", "Sgr A*, horizon", 4.30e6*M_sun, 2*G*4.30e6*M_sun/c**2, None, None,
    "défini (rayon de Schwarzschild)", "", "GRAVITY Collaboration 2020")
add("Noyaux galactiques", "M87*, horizon", 6.5e9*M_sun, 2*G*6.5e9*M_sun/c**2, None, None,
    "défini (rayon de Schwarzschild)", "", "EHT Collaboration 2019")
v0, R0 = 233e3, 8.2e3*pc
add("Galaxie", "Soleil autour du centre galactique", v0**2*R0/G, R0, 2*np.pi*R0/v0, "orbit",
    "circulaire : M déduite de la même orbite", "période orbitale", "ordres de grandeur usuels (V₀ = 233 km/s, R₀ = 8,2 kpc)")

# ---- cosmic horizon
H0 = 67.4e3/(1e6*pc)
add("Cosmos", "Sphère de Hubble aujourd'hui", hubble_fingerprint(H0).M, c/H0, 13.79e9*yr, "other",
    "défini (c/H₀)", "âge de l'Univers", "Planck Collaboration 2020")
add("Cosmos", "Sphère de Hubble au découplage (z ≈ 1090)", None, None, 3.77e5*yr, "other",
    "défini (c/H(z))", "âge au découplage", "Planck 2020 (âge au découplage, ≈ 377 kyr)")

def Hz(z, h=0.674, wm=0.1430, wr=4.18e-5):
    H100 = 100e3/(1e6*pc)
    return H100*np.sqrt(wr*(1+z)**4 + wm*(1+z)**3 + (h*h - wm - wr))

RDEF = {
 "Électron (échelle de Compton réduite)": "longueur de Compton réduite", "Proton (rayon de charge)": "rayon de charge",
 "Hydrogène, orbite de Bohr": "rayon de Bohr", "Hydrogène, raie à 21 cm (maser)": "rayon de Bohr",
 "Neutrons en superposition (COW 1975)": "séparation des faisceaux", "Atomes Rb, 54 cm (2015)": "séparation des paquets d'ondes",
 "Atomes Cs piégés 20 s (2019)": "séparation des paquets d'ondes", "Molécules 25 kDa (2019)": "délocalisation (ordre de grandeur)",
 "Microdiamant 1e-14 kg (proposition BMV)": "écart entre branches Δx", "Masse de Planck à la longueur de Planck": "longueur de Planck",
 "Terre, surface (rotation sidérale)": "rayon moyen", "Station spatiale internationale": "rayon orbital",
 "Satellite GPS": "demi-grand axe", "Lune autour de la Terre": "demi-grand axe", "Soleil, surface (rotation équatoriale)": "rayon photosphérique",
 "Mercure autour du Soleil": "demi-latus rectum a(1−e²) non ; demi-grand axe a", "Terre autour du Soleil": "demi-grand axe",
 "Jupiter autour du Soleil": "demi-grand axe", "Neptune autour du Soleil": "demi-grand axe",
 "Sirius B, surface (naine blanche)": "rayon stellaire", "Sirius A–B, orbite": "demi-grand axe",
 "PSR J0740+6620, surface (étoile à neutrons)": "rayon équatorial (NICER)", "Pulsar du Crabe, surface": "rayon stellaire",
 "PSR B1913+16, orbite": "demi-grand axe", "Double pulsar J0737−3039, orbite": "demi-grand axe", "Cygnus X-1, horizon": "rayon de Schwarzschild",
 "GW150914 à 40 Hz": "séparation képlérienne (non observable)", "S2 autour de Sgr A*": "demi-grand axe",
 "Sgr A*, horizon": "rayon de Schwarzschild", "M87*, horizon": "rayon de Schwarzschild",
 "Soleil autour du centre galactique": "rayon galactocentrique", "Sphère de Hubble aujourd'hui": "rayon de Hubble c/H₀",
 "Sphère de Hubble au découplage (z ≈ 1090)": "rayon de Hubble c/H(z)"}
RDEF["Mercure autour du Soleil"] = "demi-grand axe"
out = []
for r in ROWS:
    if r["M"] is None:  # horizon at decoupling
        f = hubble_fingerprint(Hz(1089.9)); r["M"], r["R"] = f.M, f.R
    f = Fingerprint(r["M"], r["R"], r["T"], r["clock"], r["name"])
    rk = f.kepler_residual()
    out.append({
        "categorie": r["cat"], "systeme": r["name"], "M_kg": f"{r['M']:.6e}", "R_m": f"{r['R']:.6e}",
        "T_obs_s": "" if r["T"] is None else f"{r['T']:.6e}", "nature_T_obs": r["T_stat"],
        "definition_R": RDEF.get(r["name"], ""),
        "statut_R": r["R_stat"],
        "T_P_s": f"{T_P:.6e}", "T_G_s": f"{T_G(r['M']):.6e}", "T_C_s": f"{T_C(r['R']):.6e}",
        "T_Q_s": f"{T_Q(r['M']):.6e}",
        "log10_X": f"{np.log10(f.X):.4f}", "log10_Y": f"{np.log10(f.Y):.4f}",
        "log10_O": "" if f.O is None else f"{np.log10(f.O):.4f}",
        "log10_g_sur_aP": f"{np.log10(f.g_over_aP):.4f}",
        "residu_Kepler": "" if rk is None else f"{rk:.2e}",
        "regime": " ; ".join(f.regime()), "source": r["src"]})
with open("atlas_temporel.csv", "w", newline="", encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
if __name__ == "__main__":
    for o in out:
        print(f"{o['systeme'][:44]:44s} lgX={o['log10_X']:>9s} lgY={o['log10_Y']:>9s} lgO={o['log10_O']:>8s} rK={o['residu_Kepler']:>9s}")
