# -*- coding: utf-8 -*-
"""
empreintes.py -- Temporal fingerprints / Empreintes temporelles
================================================================

A logarithmic reference frame of time scales for gravitational and quantum systems.
Référentiel logarithmique des échelles de temps des systèmes gravitationnels et quantiques.

Only numpy is required. Constants: CODATA 2018.

Base time scales / échelles de base
    T_P = sqrt(hbar G / c^5)     Planck time
    T_G = G M / c^3              gravitational time of a mass M  (= r_g / c)
    T_C = R / c                  light-crossing time of a length R
    T_Q = hbar / (m c^2)         reduced Compton (quantum) time of a mass m (with hbar, not h)
    T_obs                        time scale attached to an observable (period, duration...)

Relative frame / référentiel relatif
    X = T_G / T_C = G M / (R c^2)        compactness
    Y = T_P / T_G = M_P / M              mass in Planck units (inverse)
    O = T_obs / T_C = c T_obs / R        observed clock in light-crossing units

Nothing here modifies general relativity or quantum mechanics: every relation is a change of variables.
Rien ici ne modifie la relativité générale ni la mécanique quantique : tout est changement de variables.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Sequence

# --------------------------------------------------------------------------- constants (CODATA 2018)
c = 299_792_458.0                 # m s^-1 (exact)
G = 6.67430e-11                   # m^3 kg^-1 s^-2
hbar = 1.054_571_817e-34          # J s (exact)
k_B = 1.380_649e-23               # J K^-1 (exact)
eV = 1.602_176_634e-19            # J (exact)
T_P = np.sqrt(hbar * G / c**5)    # Planck time        5.391e-44 s
L_P = c * T_P                     # Planck length      1.616e-35 m
M_P = np.sqrt(hbar * c / G)       # Planck mass        2.176e-8 kg
a_P = c / T_P                     # Planck acceleration 5.561e51 m s^-2

GM_sun = 1.327_124_4e20           # m^3 s^-2 (IAU 2015 nominal)
M_sun = GM_sun / G               # kg, consistent with GM_sun and CODATA G
AU = 1.495_978_707e11             # m (exact, IAU 2012)
pc = 3.085_677_581_491_367e16     # m
yr = 365.25 * 86400.0             # s (Julian year)
day = 86400.0


# --------------------------------------------------------------------------- base scales
def T_C(R):  return np.asarray(R, float) / c
def T_G(M):  return G * np.asarray(M, float) / c**3
def T_Q(m):  return hbar / (np.asarray(m, float) * c**2)


# --------------------------------------------------------------------------- fingerprint
@dataclass
class Fingerprint:
    """Temporal fingerprint of a system with mass M, length R and optional observed time T_obs.

    clock : 'orbit' (Kepler constant 2*pi), 'gw' (pi, T_obs = 1/f_GW), or None.
    """
    M: float
    R: float
    T_obs: Optional[float] = None
    clock: Optional[str] = None
    name: str = ""

    @classmethod
    def from_mu(cls, mu, R, T_obs=None, clock=None, name=""):
        """Build from the gravitational parameter mu = GM (m^3 s^-2), often known far more
        precisely than G and M separately (e.g. GM_sun)."""
        return cls(mu / G, R, T_obs, clock, name)

    # absolute level (seconds)
    @property
    def times(self) -> dict:
        d = {"T_P": T_P, "T_G": float(T_G(self.M)), "T_C": float(T_C(self.R))}
        if self.T_obs is not None:
            d["T_obs"] = float(self.T_obs)
        return d

    # relative level (dimensionless)
    @property
    def X(self): return float(T_G(self.M) / T_C(self.R))
    @property
    def Y(self): return float(T_P / T_G(self.M))
    @property
    def O(self): return None if self.T_obs is None else float(self.T_obs / T_C(self.R))
    @property
    def Z(self): return float(T_P / T_C(self.R))            # = X*Y = L_P/R (dependent)
    @property
    def g_over_aP(self): return self.X**2 * self.Y          # = (GM/R^2)/a_P
    @property
    def F_static(self):                                      # Schwarzschild, static clock
        return np.sqrt(1 - 2*self.X) if self.X <= 0.5 else np.nan
    @property
    def F_orbit(self):                                       # Schwarzschild, circular geodesic
        return np.sqrt(1 - 3*self.X) if self.X <= 1/3 else np.nan

    @property
    def log_times(self) -> np.ndarray:
        """t = (ln T_P, ln T_G, ln T_C, ln T_obs)."""
        to = np.nan if self.T_obs is None else np.log(self.T_obs)
        return np.array([np.log(T_P), np.log(T_G(self.M)), np.log(T_C(self.R)), to])

    @property
    def relative(self) -> np.ndarray:
        """(ln X, ln Y, ln O) = A t."""
        return A @ self.log_times

    def kepler_residual(self) -> Optional[float]:
        """r_K = ln O + 1/2 ln X - ln C_orb (0 for an exact Keplerian orbit)."""
        if self.T_obs is None or self.clock not in ("orbit", "gw"):
            return None
        C = 2*np.pi if self.clock == "orbit" else np.pi
        lnX, _, lnO = self.relative
        return float(lnO + 0.5*lnX - np.log(C))

    def regime(self) -> list[str]:
        """Cells of the hyperplane arrangement occupied by the system."""
        out = []
        X, Y = self.X, self.Y
        # conventional classification (Schwarzschild interpretation), not universal boundaries
        out.append("R <= r_s (X >= 1/2)" if X >= 0.5 else
                   "between ISCO and r_s (1/6 < X < 1/2)" if X > 1/6 else
                   "1e-4 <= X <= 1/6" if X >= 1e-4 else "X < 1e-4 (Newtonian to 1e-4)")
        out.append("sub-Planckian mass (Y > 1)" if Y > 1 else "super-Planckian mass (Y < 1)")
        out.append("R below Planck length (XY > 1)" if X*Y > 1 else "R above Planck length")
        return out


# --------------------------------------------------------------------------- linear structure
#: Map from log-times t = (ln T_P, ln T_G, ln T_C, ln T_obs) to (ln X, ln Y, ln O).
A = np.array([[0.0, 1.0, -1.0, 0.0],
              [1.0, -1.0, 0.0, 0.0],
              [0.0, 0.0, -1.0, 1.0]])

def scale_invariance_check() -> np.ndarray:
    """A @ (1,1,1,1) = 0 : a change of time unit leaves (X, Y, O) unchanged."""
    return A @ np.ones(4)

#: Dimension matrix (rows M, L, T) of the variables (M, R, T_obs, G, c, hbar).
DIM_VARS = ["M", "R", "T_obs", "G", "c", "hbar"]
DIM = np.array([[1, 0, 0, -1, 0, 1],
                [0, 1, 0, 3, 1, 2],
                [0, 0, 1, -2, -1, -1]], float)

def buckingham() -> tuple[int, np.ndarray]:
    """Rank of the dimension matrix and an integer basis of its kernel (dimensionless groups).
    The basis returned is the one giving X, Y^-2 ... expressed back as X, Y, O (see paper, sect. 4.3)."""
    rank = np.linalg.matrix_rank(DIM)
    # exponent vectors of X = G M R^-1 c^-2, Y = hbar^1/2 c^1/2 G^-1/2 M^-1, O = c T_obs R^-1
    X = np.array([1, -1, 0, 1, -2, 0.0])
    Y = np.array([-1, 0, 0, -0.5, 0.5, 0.5])
    O = np.array([0, -1, 1, 0, 1, 0.0])
    basis = np.vstack([X, Y, O])
    assert np.allclose(DIM @ basis.T, 0), "X, Y, O must be dimensionless"
    assert np.linalg.matrix_rank(basis) == 3
    return int(rank), basis


@dataclass
class Hyperplane:
    """Affine hyperplane n . p = b in a log space; residual r(p) = (n . p - b)/|n| (signed distance)."""
    n: np.ndarray
    b: float
    name: str = ""
    def residual(self, p) -> float:
        n = np.asarray(self.n, float)
        return float((n @ np.asarray(p, float) - self.b) / np.linalg.norm(n))

# hyperplanes in the (ln X, ln Y, ln O) space
KEPLER = Hyperplane(np.array([0.5, 0.0, 1.0]), np.log(2*np.pi), "Kepler (orbital period)")
KEPLER_GW = Hyperplane(np.array([0.5, 0.0, 1.0]), np.log(np.pi), "Kepler (GW period)")
HORIZON = Hyperplane(np.array([1.0, 0, 0]), np.log(0.5), "Schwarzschild horizon X = 1/2")
ISCO = Hyperplane(np.array([1.0, 0, 0]), np.log(1/6), "ISCO X = 1/6")
PLANCK_MASS = Hyperplane(np.array([0, 1.0, 0]), 0.0, "Planck mass Y = 1")
PLANCK_LENGTH = Hyperplane(np.array([1.0, 1.0, 0]), 0.0, "Planck length XY = 1")


def eliminate(coeffs: np.ndarray, var_index: Sequence[int]) -> np.ndarray:
    """Given k log-linear quantities ln q_i = sum_j coeffs[i, j] ln p_j, return the basis of
    weights w such that ln prod q_i^{w_i} does not depend on the parameters p_j, j in var_index.
    (kernel of coeffs[:, var_index]^T)."""
    C = np.asarray(coeffs, float)[:, list(var_index)].T
    u, s, vt = np.linalg.svd(C)
    null = vt[(s > 1e-12).sum():]
    return null


def propagate(J: np.ndarray, cov_log: np.ndarray) -> np.ndarray:
    """Exact first-order propagation in log space: Sigma_out = J Sigma_in J^T.
    For log-linear maps (power laws) this is exact, not an approximation."""
    J = np.atleast_2d(J)
    return J @ cov_log @ J.T


def elasticity(f, p0: dict, key: str, step: float = 0.02) -> float:
    """Numerical elasticity d ln f / d ln p_key (central difference in log space)."""
    up = dict(p0); dn = dict(p0)
    up[key] = p0[key] * (1 + step); dn[key] = p0[key] / (1 + step)
    return float((np.log(f(**up)) - np.log(f(**dn))) / (np.log(1 + step) * 2))


# --------------------------------------------------------------------------- quantum extension
def phi_G(m, dx, T_obs):
    """Self-gravity phase of a superposition: T_obs / (Y^2 T_C(dx)) = G m^2 T_obs / (hbar dx)."""
    Y = M_P / m
    return T_obs / (Y**2 * T_C(dx))

def phi_clock(dE, dtau):
    """Internal-clock which-path phase: dE dtau / hbar."""
    return dE * dtau / hbar

def dtau_potential(g, dh, T_obs):
    """Upper bound of the proper-time difference between two branches separated by dh in a field g.
    (In a closed free-fall interferometer the leading-order difference cancels; see Roura 2020.)"""
    return T_obs * g * dh / c**2

def q4_threshold(m, dE, g):
    """Minimal duration for phi_G * phi_clock >= 1:  T_obs >= Y sqrt(T_clock T_g),
    with T_clock = hbar/dE and T_g = c/g. Independent of the branch separation dx."""
    return (M_P / m) * np.sqrt((hbar / dE) * (c / g))


# --------------------------------------------------------------------------- cosmological horizon
def hubble_fingerprint(H, Omega_tot=1.0, T_obs=None):
    """Fingerprint of the Hubble sphere: R = c/H, M = (4 pi/3) R^3 rho, rho = Omega_tot 3H^2/(8 pi G).
    Then X = Omega_tot / 2 exactly, at all epochs."""
    R = c / H
    rho = Omega_tot * 3 * H**2 / (8 * np.pi * G)
    M = 4 * np.pi / 3 * R**3 * rho
    return Fingerprint(M, R, T_obs, None, "Hubble sphere")


if __name__ == "__main__":
    print("A (1,1,1,1) =", scale_invariance_check())
    r, B = buckingham()
    print("rank of dimension matrix =", r, "-> number of independent groups =", len(DIM_VARS) - r)
    e = Fingerprint(M_sun, AU, 365.256363004*day, "orbit", "Earth-Sun")
    print(e.name, "X=%.4e Y=%.4e O=%.4e  r_K=%.2e" % (e.X, e.Y, e.O, e.kepler_residual()))
