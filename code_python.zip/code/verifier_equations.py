# -*- coding: utf-8 -*-
"""Symbolic verification of every equation of the paper (sympy): exponents, identities, dimensions,
factors 2, pi, hbar vs h.   python verifier_equations.py"""
import sympy as sp




G, c, hb, M, m, R, T, dx, dE, g, H, Om, d = sp.symbols("G c hbar M m R T_obs Delta_x Delta_E g H Omega d", positive=True)
ok = []
def check(name, expr):
    r = sp.simplify(expr)
    assert r == 0, (name, r)
    ok.append(name)

# dimensions (M, L, T)
dim = {G: (-1, 3, -2), c: (0, 1, -1), hb: (1, 2, -1), M: (1, 0, 0), m: (1, 0, 0), R: (0, 1, 0),
       T: (0, 0, 1), dx: (0, 1, 0), dE: (1, 2, -2), g: (0, 1, -2), H: (0, 0, -1), Om: (0, 0, 0), d: (0, 1, 0)}
def dims(expr):
    e = sp.powsimp(sp.expand_power_base(expr, force=True), force=True)
    tot = [0, 0, 0]
    for b, p in e.as_powers_dict().items():
        if b in dim:
            for i in range(3): tot[i] += p * dim[b][i]
    return tuple(sp.nsimplify(x) for x in tot)

TP = sp.sqrt(hb*G/c**5); TG = G*M/c**3; TC = R/c; TQ = hb/(m*c**2); MP = sp.sqrt(hb*c/G)
LP = c*TP; aP = c/TP; lamC = hb/(M*c)

# 1. Planck exponents: unique solution
a, b, gg = sp.symbols("a b gg")
sol = sp.solve([a - b, 2*a + 3*b + gg, -a - 2*b - gg - 1], [a, b, gg])
assert sol == {a: sp.Rational(1, 2), b: sp.Rational(1, 2), gg: sp.Rational(-5, 2)}; ok.append("exposants de T_P")
for name, e in [("T_P", TP), ("T_G", TG), ("T_C", TC), ("T_Q", TQ)]:
    assert dims(e) == (0, 0, 1), (name, dims(e)); ok.append(f"dimension {name} = T")
# 2. identities
check("T_G(M_P) = T_P", TG.subs(M, MP) - TP)
check("T_G(m) T_Q(m) = T_P^2", TG.subs(M, m)*TQ - TP**2)
X = TG/TC; Y = TP/TG; O = T/TC
for nm, e in [("X", X), ("Y", Y), ("O", O)]:
    assert dims(e) == (0, 0, 0); ok.append(f"{nm} sans dimension")
check("X = GM/(R c^2)", X - G*M/(R*c**2))
check("Y = M_P/M", Y - MP/M)
check("XY = L_P/R", X*Y - LP/R)
check("XY^2 = lambdabar_C/R = T_Q/T_C", X*Y**2 - lamC/R)
check("X^2 Y = (GM/R^2)/a_P", X**2*Y - (G*M/R**2)/aP)
# 3. Kepler
Tk = 2*sp.pi*sp.sqrt(R**3/(G*M))
check("O sqrt(X) = 2 pi (Kepler)", (Tk/TC)*sp.sqrt(X) - 2*sp.pi)
check("GW: T = P/2 -> O sqrt(X) = pi", (Tk/2/TC)*sp.sqrt(X) - sp.pi)
# 4. Schwarzschild thresholds
check("r_s/c = 2 T_G", (2*G*M/c**2)/c - 2*TG)
check("X = 1/2 at R = r_s", X.subs(R, 2*G*M/c**2) - sp.Rational(1, 2))
check("X = 1/6 at R = 6GM/c^2 (ISCO)", X.subs(R, 6*G*M/c**2) - sp.Rational(1, 6))
# 5. quantum: self-gravity phase, clock phase, product
Yq = MP/m
phiG = T/(Yq**2*(dx/c))
check("phi_G = G m^2 T/(hbar dx)", phiG - G*m**2*T/(hb*dx))
assert dims(phiG) == (0, 0, 0); ok.append("phi_G sans dimension")
dtau = T*g*dx/c**2
assert dims(dtau) == (0, 0, 1); ok.append("Delta tau = T g dx/c^2 a la dimension d'un temps")
phiC = dE*dtau/hb
assert dims(phiC) == (0, 0, 0); ok.append("phi_clock sans dimension (hbar, pas h)")
prod = sp.simplify(phiG*phiC)
assert sp.diff(prod, dx) == 0; ok.append("produit independant de Delta_x")
check("produit = T^2/(Y^2 T_clock T_g)", prod - T**2/(Yq**2*(hb/dE)*(c/g)))
Tmin = Yq*sp.sqrt((hb/dE)*(c/g))
check("seuil : produit = 1 en T = Y sqrt(T_clock T_g)", prod.subs(T, Tmin) - 1)
dxeq = sp.solve(sp.Eq(phiC.subs(T, Tmin), 1), dx)[0]
check("dx_eq = hbar c^2/(dE g T)", dxeq - hb*c**2/(dE*g*Tmin))
check("et phi_G = 1 en dx_eq", phiG.subs({T: Tmin, dx: dxeq}) - 1)
# BMV entangling phase uses the inter-mass distance d, same functional form
phiBMV = G*m**2*T/(hb*d)
check("phase BMV = T/(Y^2 T_C(d))", phiBMV - T/(Yq**2*(d/c)))
# 6. Hubble sphere
Rh = c/H; rho = Om*3*H**2/(8*sp.pi*G); Mh = sp.Rational(4, 3)*sp.pi*Rh**3*rho
check("X_Hubble = Omega/2", G*Mh/(Rh*c**2) - Om/2)
# 7. scale invariance and Buckingham
A = sp.Matrix([[0, 1, -1, 0], [1, -1, 0, 0], [0, 0, -1, 1]])
assert A*sp.ones(4, 1) == sp.zeros(3, 1); ok.append("A 1 = 0")
D = sp.Matrix([[1, 0, 0, -1, 0, 1], [0, 1, 0, 3, 1, 2], [0, 0, 1, -2, -1, -1]])
assert D.rank() == 3
B = sp.Matrix([[1, -1, 0, 1, -2, 0], [-1, 0, 0, -sp.Rational(1, 2), sp.Rational(1, 2), sp.Rational(1, 2)], [0, -1, 1, 0, 1, 0]])
assert D*B.T == sp.zeros(3, 3) and B.rank() == 3; ok.append("rang 3, base du noyau (X, Y, O)")
# 8. Proposition: without hbar only X and O ; without G, Y only via X Y^2
Dn = D[:, :5]
assert Dn.rank() == 3 and len(Dn.nullspace()) == 2
ns = sp.Matrix.hstack(*Dn.nullspace())
XO = sp.Matrix([[1, -1, 0, 1, -2], [0, -1, 1, 0, 1]]).T
assert sp.Matrix.hstack(ns, XO).rank() == 2; ok.append("sans hbar : noyau = span(X, O)")
Dg = D[:, [0, 1, 2, 4, 5]]
nsg = sp.Matrix.hstack(*Dg.nullspace())
XY2 = sp.Matrix([-1, -1, 0, -1, 1])   # exponents of hbar/(M c R) on (M,R,T,c,hbar)
Ov = sp.Matrix([0, -1, 1, 1, 0])
assert sp.Matrix.hstack(nsg, XY2, Ov).rank() == 2; ok.append("sans G : noyau = span(O, X Y^2)")
check("X Y^2 = hbar/(M c R)", X*Y**2 - hb/(M*c*R))
print(f"{len(ok)} verifications reussies :")
for o in ok: print("  ok", o)
