# -*- coding: utf-8 -*-
"""Recompute every number quoted in the paper, then the atlas and the figures.
   python reproduire_papier.py      (requires numpy, scipy, matplotlib)"""
import subprocess, sys, json, numpy as np
from empreintes import *
P = lambda *a: print(*a)
P("== Constantes / constants")
P(f"T_P = {T_P:.6e} s ; L_P = {L_P:.6e} m ; M_P = {M_P:.6e} kg ; a_P = {a_P:.4e} m/s^2")
P(f"T_G(Soleil/Sun) = {T_G(M_sun)*1e6:.6f} µs ; T_G(Terre/Earth) = {T_G(GM_E/G if False else 3.986004418e14/G)*1e9:.4f} ns")
P("== Structure")
P("A(1,1,1,1) =", scale_invariance_check(), "; rang/rank =", buckingham()[0])
e = Fingerprint(M_sun, AU, 365.256363004*day, "orbit")
P(f"Terre-Soleil: X={e.X:.4e} Y={e.Y:.4e} O={e.O:.4e} O*sqrt(X)={e.O*np.sqrt(e.X):.6f} (2pi={2*np.pi:.6f})")
P("== Quantique / quantum")
for m in [1.6749e-27, 1e-14]:
    P(f"m={m:.3e}: Y={M_P/m:.3e} T_Q={T_Q(m):.3e} s  T_G*T_Q/T_P^2={T_G(m)*T_Q(m)/T_P**2:.12f}")
P(f"BMV phi_G(200 µm)={phi_G(1e-14,200e-6,2.5):.3f} ; phi_G(450 µm)={phi_G(1e-14,450e-6,2.5):.3f}")
g = 9.81
P(f"T_g = c/g = {c/g:.4e} s = {c/g/yr:.3f} an/yr")
for nm, dE in [("NV 2.87 GHz", hbar*2*np.pi*2.87e9), ("optique/optical 2 eV", 2*eV), ("Th-229 8.4 eV", 8.4*eV)]:
    for m in [1e-14, 1e-12]:
        T4 = q4_threshold(m, dE, g); dx = hbar*c**2/(dE*g*T4)
        P(f"  {nm:22s} m={m:.0e}: T_min={T4:.4g} s ; dx_eq={dx:.3g} m")
pb = phi_G(1e-14, 2.5e-4, 2.5)*phi_clock(2*eV, dtau_potential(g, 2.5e-4, 2.5))
P(f"BMV produit/product phi_G*phi_clock (horloge optique) = {pb:.3e}")
P("== Cosmos")
H0 = 67.4e3/(1e6*pc)
hb = hubble_fingerprint(H0, T_obs=13.79e9*yr)
P(f"Hubble aujourd'hui: X={hb.X:.6f}  O=H0*t0={hb.O:.4f}  Y={hb.Y:.3e}")
subprocess.run([sys.executable, "atlas.py"], stdout=subprocess.DEVNULL)
for L in ("fr", "en"):
    subprocess.run([sys.executable, "figures.py", L])
